﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.UI.WebControls;
using BO.DAL.EntityModels;
using BO.Core.Models;
using BO.Core.Models.SEC;
using BO.CORE;
using BO.CORE.Interfaces;
using BO.DAL.Data.SEC;
using BO.DAL.Interfaces.SEC;
namespace BO.Core.Services.SEC
{
    #region Interfaces 
    public interface IUsersService : IService<UserModel, Identity_User, IUsers>
    {
    }
    #endregion

    public class UsersService : ServiceBase<UserModel, Identity_User, Users>, IUsersService
    {
        public UsersService()
            : this(new Users())
        {

        }
        public UsersService(Users usr)
            : base(usr)
        { }
    }
}
