﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BO.CORE.Interfaces
{
    public interface IMapper
    {
        void Reset();
        void Configure();

    }
}
