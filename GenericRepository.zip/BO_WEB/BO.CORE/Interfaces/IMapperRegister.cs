﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BO.CORE.Interfaces
{
    public interface IMapperRegister
    {
        void Configure();
        void Initialize();
    }
}
