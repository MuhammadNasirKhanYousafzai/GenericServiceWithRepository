﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using sCMS.Dal;
using BO.DAL.Interfaces.SEC;
using BO.DAL.EntityModels;
using BO.DAL;
using BO.DAL.Infrastructure;
using BO.DAL.Interfaces;
using System.Linq.Expressions;

namespace BO.DAL.Data.SEC
{
    public class Users : RepositoryBase<Identity_User>, IUsers
    {
        public Users()
            : this(new BORepositoryContext())
        {
        }
        public Users(IRepositoryContext repositoryContext)
            : base(repositoryContext)
        {
        }
        public override Expression<Func<Identity_User, bool>> GetFilters()
        {
            return x => x.UserID == 1;
        }
        public override Expression<Func<Identity_User, bool>> SearchFilters(Identity_User update){
        return x => x.UserID == update.UserID;
        }
    }
}
