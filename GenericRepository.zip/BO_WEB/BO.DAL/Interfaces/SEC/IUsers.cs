﻿using BO.DAL.EntityModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace BO.DAL.Interfaces.SEC
{
    public interface IUsers : IRepository<Identity_User>
    {
    }
}
