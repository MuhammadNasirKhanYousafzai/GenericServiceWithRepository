﻿using BO.Core.Models.SEC;
using BO.Core.Services.SEC;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace WebForTest.Controllers
{
    public class HomeController : Controller
    {
        IUsersService serUSer;
        public HomeController()
            : this(new UsersService())
        { }
        public HomeController(IUsersService usr)
        {
            serUSer = usr ?? new UsersService();
        }
        public ActionResult Index()
        {
            UserModel result = new UserModel();
            try
            {
                result.UserList = serUSer.GetAll();
            }
            catch (Exception ex)
            {

                throw ex;
            }
            return View(result);
        }

        public ActionResult About()
        {
            ViewBag.Message = "Your application description page.";

            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }
    }
}